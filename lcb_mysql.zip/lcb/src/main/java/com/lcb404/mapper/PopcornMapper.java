package com.lcb404.mapper;

import com.lcb404.command.PopcornVO;

public interface PopcornMapper {

	public PopcornVO getList(int POPCORN_CODE);
}
