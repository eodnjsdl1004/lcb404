package com.lcb404.mapper;

import com.lcb404.command.EventVO;

public interface EventMapper {
	public EventVO getEvent(int eno);
}
