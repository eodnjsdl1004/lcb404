package com.lcb404.service;

import com.lcb404.command.EventVO;

public interface EventService {
	public EventVO getEvent(int eno);
}
