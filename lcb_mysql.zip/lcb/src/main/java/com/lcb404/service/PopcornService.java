package com.lcb404.service;

import com.lcb404.command.PopcornVO;

public interface PopcornService {
	public PopcornVO getList(int POPCORN_CODE);
}
