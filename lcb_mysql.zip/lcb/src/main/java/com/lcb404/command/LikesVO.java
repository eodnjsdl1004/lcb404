package com.lcb404.command;

public class LikesVO {
	private int LIKES_NUM;
	private String MEMBERS_ID;
	private int MOVIE_CODE;

}
