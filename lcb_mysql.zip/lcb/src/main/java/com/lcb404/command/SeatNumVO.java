package com.lcb404.command;

import lombok.Data;

@Data
public class SeatNumVO {

	private int total;
	private int timetable_number;
	private String row;
	private String seat;
}
