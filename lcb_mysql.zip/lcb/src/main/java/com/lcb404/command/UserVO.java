package com.lcb404.command;

import lombok.Data;

@Data
public class UserVO {
	private String MEMBERS_ID;
	private String MEMBERS_PW;
	private String MEMBERS_NAME;
	private String MEMBERS_NICKNAME;
	private String MEMBERS_PHONE;
	private String MEMBERS_EMAIL;
	private String addrZipNum;
	private String addrBasic;
	private String addrDetail;
	private String MEMBERS_GRADE;
	private String MEMBERS_VIP;
	private String MEMBERS_STATUS;
	private String MEMBERS_MONEY;
	private int MEMBERS_POINT;
	private String MEMBERS_INFORMATION;
	private String MEMBERS_IMAGE;
	private String MEMBERS_REGDATE;
	private int VOTER;
	
}
