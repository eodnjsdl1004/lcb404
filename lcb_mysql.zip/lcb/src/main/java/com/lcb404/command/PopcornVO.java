package com.lcb404.command;

import lombok.Data;

@Data
public class PopcornVO {
	private int POPCORN_CODE;
	private String MEMBERS_ID;
	private String POPCORN_TITLE1;
	private String POPCORN_TITLE2;
	private String POPCORN_CONTENT1;
	private String POPCORN_CONTENT2;
	private String POPCORN_CONTENT3;
	private String POPCORN_IMAGE;
	private String POPCORN_PRICE;
	private String POPCORN_REGDATE;
	private String POPCORN_HIT;	
}
