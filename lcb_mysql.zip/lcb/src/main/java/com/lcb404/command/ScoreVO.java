package com.lcb404.command;

import lombok.Data;

@Data
public class ScoreVO {

	private int SCORE_NUM;
	private int MOVIE_CODE;
	private String MEMBERS_ID;
	private int SCORE;
}
