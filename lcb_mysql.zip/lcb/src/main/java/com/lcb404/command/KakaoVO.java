package com.lcb404.command;

import lombok.Data;

@Data
public class KakaoVO {
	private String Kakao_ID;
	private String Kakao_Email;
	private String Kakao_NickName;
}
