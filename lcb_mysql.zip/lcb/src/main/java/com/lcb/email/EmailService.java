package com.lcb.email;

public interface EmailService {
    public void sendMail(EmailDTO dto);
}