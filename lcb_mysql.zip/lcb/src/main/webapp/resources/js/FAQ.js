var a1 = document.querySelector(".a1");
var a2 = document.querySelector(".a2");
var a3 = document.querySelector(".a3");
var a4 = document.querySelector(".a4");
var a5 = document.querySelector(".a5");
var a6 = document.querySelector(".a6");
var a7 = document.querySelector(".a7");
var a8 = document.querySelector(".a8");
var a = document.querySelectorAll(".ic_q");
   

a[0].onclick = function(){
      
      
      a1.style.display = "table-row";
      a2.style.display ="none"
         a3.style.display ="none"
            a4.style.display ="none"
               a5.style.display ="none"
                  a6.style.display ="none"
                     a7.style.display ="none"
                        a8.style.display ="none"
   }
   
a[1].onclick = function(){
      
      a2.style.display = "table-row";
      a1.style.display ="none"
         a3.style.display ="none"
            a4.style.display ="none"
               a5.style.display ="none"
                  a6.style.display ="none"
                     a7.style.display ="none"
                        a8.style.display ="none"
   }
a[2].onclick = function(){

a3.style.display = "table-row";
a1.style.display ="none"
   a2.style.display ="none"
      a4.style.display ="none"
         a5.style.display ="none"
            a6.style.display ="none"
               a7.style.display ="none"
                  a8.style.display ="none"
}
a[3].onclick = function(){


a4.style.display = "table-row";
a1.style.display ="none"
   a2.style.display ="none"
      a3.style.display ="none"
         a5.style.display ="none"
            a6.style.display ="none"
               a7.style.display ="none"
                  a8.style.display ="none"
}
a[4].onclick = function(){
a5.style.display = "table-row";
   a1.style.display ="none"
      a2.style.display ="none"
         a3.style.display ="none"
            a4.style.display ="none"
               a6.style.display ="none"
                  a7.style.display ="none"
                     a8.style.display ="none"

}
a[5].onclick = function(){

a6.style.display = "table-row";
   a1.style.display ="none"
      a2.style.display ="none"
         a3.style.display ="none"
            a4.style.display ="none"
               a5.style.display ="none"
                  a7.style.display ="none"
                     a8.style.display ="none"
}
a[6].onclick = function(){


a7.style.display = "table-row";
a1.style.display ="none"
   a2.style.display ="none"
      a3.style.display ="none"
         a4.style.display ="none"
            a5.style.display ="none"
               a6.style.display ="none"
                  a8.style.display ="none"
}
a[7].onclick = function(){


a8.style.display = "table-row";
a1.style.display ="none"
   a2.style.display ="none"
      a3.style.display ="none"
         a4.style.display ="none"
            a5.style.display ="none"
               a6.style.display ="none"
                  a7.style.display ="none"
}
