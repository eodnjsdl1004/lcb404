$(function(){
    $('#birthDayCp').click(function(){
      $('#birthDayCplist').focus();
      return false;
    });
});

$(function(){
    $('.#pointSave').click(function(){
         $('#pointUselist').focus();
         return false;
       });
});

$(function(){
    $('.#pointSave').click(function(){
         $('#pointSavelist').focus();
         return false;
       });
    
  });